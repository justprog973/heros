<?php
/*
 * Plugin Name: heros metaboxes
 * Plugin URI:
 * Description: Adding Metaboxes for heros
 * Version: 1.0.0
 * Author: JUSTPROG
 * Author URI:
 * Licence: GLP2
 * Licence URI:
 * Text Domain: heros-metaboxes
 * Domain Patch: /languages
 */

if( !Defined('WPINC')) {
    die();
}

include_once("includes/metaboxes.php");
include_once("includes/enqueue-assets.php");
