<?php

function heros_metaboxes_admin_scripts()
{
    global $pagenow;
    if($pagenow !== 'post.php') return;
    wp_enqueue_script('heros-metaboxes-scripts', plugins_url(
        'heros-metaboxes/dist/assets/js/admin.js'), ['jquery'], '1.0.0', true);

    wp_enqueue_style('justheros-metaboxes-stylesheet', plugins_url(
        'heros-metaboxes/dist/assets/css/admin.css'), [], '1.0.0', 'all');
}

add_action('admin_enqueue_scripts', 'heros_metaboxes_admin_scripts');