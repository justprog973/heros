<?php

function heros_add_meta_box()
{
    add_meta_box(
        'justheros_post_metabox',
        'Post Settings',
        'heros_post_metabox_html',
        'post',
        'normal',
        'default'
    );
}

add_action('add_meta_boxes', 'heros_add_meta_box');

function heros_post_metabox_html($post)
{
    $subtitle = get_post_meta($post->ID, 'justheros_post_subtitle', true);
    $layout = get_post_meta($post->ID, 'justheros_post_layout', true);
    wp_nonce_field('heros_update_post_metaboxes', 'heros_update_post_nonce');
    ?>
    <p>
        <label for="heros_post_metaboxes_html"><?php esc_html_e('Post Subtitle', 'heros-metaboxes'); ?></label>
        <br/>
        <input class="widefat" type="text" name="heros_post_subtitle_field" id="heros_post_metaboxes_html"
               value="<?= esc_attr($subtitle) ?>"/>
    </p>
    <p>
        <label for="heros_post_layout_field"><?php esc_html_e('Layout', 'heros-metaboxes'); ?></label>
        <select class="widefat" name="heros_post_layout_field" id="heros_post_layout_field">
            <option <?php selected($layout, 'full') ?>
                    value="full"><?php esc_html_e('Full Width', 'heros-metaboxes') ?></option>
            <option <?php selected($layout, 'sidebar') ?>
                    value="sidebar"><?php esc_html_e('Post With Sidebar', 'heros-metaboxes') ?></option>
        </select>
    </p>
    <?php
}

function heros_save_post_metaboxes($post_id, $post)
{
    $edit_cap = get_post_type_object($post->post_type)->cap->edit_post;
    if (!current_user_can($edit_cap, $post_id)) {
        return;
    }

    if (!isset($_POST['heros_update_post_nonce']) ||
        !wp_verify_nonce($_POST['heros_update_post_nonce'], 'heros_update_post_metaboxes')
    ) {
        return;
    }
    if (array_key_exists('heros_post_subtitle_field', $_POST)) {
        update_post_meta(
            $post_id,
            'heros_post_subtitle',
            sanitize_text_field($_POST['heros_post_subtitle_field']));
    }
    if (array_key_exists('heros_post_layout_field', $_POST)) {
        update_post_meta(
            $post_id,
            'heros_post_layout',
            sanitize_text_field($_POST['heros_post_layout_field']));
    }
}

add_action('save_post', 'heros_save_post_metaboxes', 10, 2);